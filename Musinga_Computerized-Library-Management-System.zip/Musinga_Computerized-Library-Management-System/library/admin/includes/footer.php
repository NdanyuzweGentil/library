   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                &copy; 2021 Computerized Library Management System |<a href="#" target="_blank"  > Designed by : Musinga</a> 
                </div>

            </div>
        </div>
    </section>